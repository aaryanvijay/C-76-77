import React from 'react';
import LoginScreen from './screens/LoginScreen'

export default class App extends React.Component {
  render(){
    return (
      
        <LoginScreen />
      
    );
  }
}
